import{o as a}from"./Brt01SwS.js";a();
